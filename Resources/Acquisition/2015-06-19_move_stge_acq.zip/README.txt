Author: Stephanie Fung
Date: 2015-06-19

Todo:
* Add field to name the text files

Instructions:
* Same as the stage moving GUI except for acquire

Notes:
* If acquisition doesn't work
** Make sure oscilloscope is connected
** Make sure to start the TekVISA Resource Manager
** Check the address
* filename input to function must be alphanumeric
