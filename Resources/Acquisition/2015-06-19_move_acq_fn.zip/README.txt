Author: Stephanie Fung
Date: 2015-06-19

Instructions:
* Same as the stage moving GUI except for acquire
* Enter in the filename and then click save

Notes:
* If acquisition doesn't work
** Make sure oscilloscope is connected
** Make sure to start the TekVISA Resource Manager
** Check the address
* filename input to function must be alphanumeric
* saving take quite a long time.....
