% plot1024points.m 
% plot and list 1024 points

[x,y]=importAgilentBin('myFileName.bin',1)
plot(x,y)