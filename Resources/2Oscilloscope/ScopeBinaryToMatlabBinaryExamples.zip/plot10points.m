% plot10points.m 
% plot and list 10 points

[x,y]=importAgilentBin('points10.bin',1)
plot(x,y)